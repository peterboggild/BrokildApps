BLACK RIDER
An analogue monosynth that sits between the screaming Sallen-Key and the
round transistor ladder. Two oscillators, one filter with two circuits, a
patch bay that wires anything to anything, and the effects a monosynth
actually gets played through.
Brokild Apps  -  build 260823.7  -  August 2026  -  Windows 64-bit


WHAT IS IN HERE
---------------
  Black Rider.vst3            the plugin (a FOLDER - copy the whole thing)
  Black Rider.exe             the same instrument, standalone
  Black-Rider-Manual.pdf      quick start, every panel, the patch bay


INSTALL
-------
  1. Copy the whole "Black Rider.vst3" FOLDER into your system VST3
     directory:  C:\Program Files\Common Files\VST3\
     A sub-folder such as ...\VST3\Brokild\ is fine; hosts look inside.
  2. Rescan plugins in your DAW. It appears as an INSTRUMENT called
     Black Rider, by Brokild.
  3. Or just run Black Rider.exe, which picks its own audio and MIDI
     devices from its options menu, and has a keyboard of its own.


THE THREE FILTERS
-----------------
  GROWL and SCREAM are the same two-pole Sallen-Key circuit, with a diode
  clipper in the feedback path - the MS-20 idea. They keep their low end as
  PEAK rises. GROWL crosses into self-oscillation only near the top of the
  PEAK dial, so for most of the travel it is a gnarly resonance. SCREAM
  crosses just past TWO O'CLOCK and is then pushed hard into the diodes,
  so the top of the dial is a loud, filthy howl - and since it oscillates exactly at the cutoff and tracks the keyboard through KEY,
  a SCREAM patch with KEY up is a playable in-tune oscillator on its own.

  LADDER is a four-pole transistor ladder with saturation in every stage -
  the Moog idea. Its resonance is round, its bass thins as PEAK rises, and
  it self-oscillates into a pure sine.

  All three are on one FILTER panel with a switch between them. The same
  patch flipped between them is three different instruments.


THE SEED DIAL
-------------
  The red LED in the header is the SEED dial, 000 to 199. Every one of
  those two hundred numbers IS a patch, generated from the number alone -
  so the same number is the same sound on any machine. Drag the digits,
  roll the wheel, or use the arrows; RANDOM dials one at random. The
  PATCHES menu lists all two hundred grouped by category (bass, lead, pad,
  organ, strings, pluck, brass, keys, drone, sync, noise), with twelve
  hand-made SIGNATURE patches at the top. The dial reads the seed you
  started from; tweak a knob and the sound is yours, saved with the patch.


THIRTY SECONDS OF INSTRUCTIONS
------------------------------
  - Press PATCHES and pick one. BLACK BASS and ACID RIDER are the low end;
    RIDER LEAD and SCREAM SWEEP show off the Sallen-Key; THREE RIDERS and
    GHOST ORGAN are the polyphonic, stereo-spread patches; FEEDBACK HOWL is
    the old MS-20 feedback trick wired through the bay.
  - Turn the two big CUTOFF knobs and the PEAK beside the low pass, and
    flip GROWL / SCREAM / LADDER to hear the character change under one
    setting. On SCREAM, PEAK past two o'clock makes the filter sing on its own.
  - The two oscillators drift and slowly fall into lock when VINTAGE is up;
    the LOCK lamp on VCO 1 lights when they have. Turn VINTAGE down for a
    clean, stable, modern tone.
  - Press PATCH BAY. The panel grows a wing to the right. Drag a cable from
    a red hole to a black one, roll the wheel over it to set the amount,
    double-click to pull it out. Anything into anything.
  - The LFO and the tape delay each have a sync row - FREE, 1/1 to 1/16,
    with T and D for triplet and dotted - locked to the host tempo.
  - There is a keyboard along the bottom with a pitch and a mod wheel, for
    when there is no MIDI keyboard in the room. On a computer keyboard the
    home row is an octave and Q / W shift it.


THE CHORD STEREO SPREAD
-----------------------
  In POLY 3 mode, an incoming chord is placed across the stereo field with
  the bottom note in the centre and the higher notes spread left and right;
  a two-note chord goes hard left and right. The SPREAD knob sets how wide.
  It is the fastest way to make three oscillators sound like a section.


PATCHES
-------
  A patch is a small JSON file holding all the panel values and nothing
  else - the cables included. They go in a folder called "User presets"
  beside the installed .vst3, so a library travels with the plugin. Where
  that cannot be written to, Documents\Black Rider Presets is used instead.
  Saving somewhere else once makes that the new folder, remembered in your
  own settings rather than in the project. The DAW project keeps its own
  full copy of everything regardless.


NOTES
-----
  The interface is drawn in a WebView2 surface, which every current Windows
  10 and 11 already has. If the window comes up blank, install the free
  Microsoft Edge WebView2 Runtime and reopen the plugin. The audio keeps
  working with the window shut either way.

  If Windows refuses to load the plugin and mentions an "Application Control
  policy", that is Smart App Control. It decides per FILE from a cloud
  reputation lookup, and rebuilding the identical program usually clears it;
  most machines do not have it enabled at all.

  The output has a soft ceiling that is always in place. Nothing here - not
  a screaming filter, not a feedback patch through the bay - can put a spike
  above full scale into your monitors.

  Free. No installer, no account, no telemetry, no network access at all.
  Play unsafely, unwisely, and unboringly.

  Peter Boggild / Brokild, August 2026.


