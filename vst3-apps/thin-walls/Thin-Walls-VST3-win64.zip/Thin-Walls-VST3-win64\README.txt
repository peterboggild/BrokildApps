THIN WALLS  -  a Brokild effect  -  build 260921.1

An apartment of three rooms and three doors. Place up to four sound sources and
a binaural listener anywhere, walk around, open and shut the doors. Image-source
reflections, doorway diffraction, door and wall transmission, coupled room
fields calibrated to the physics, and a measured head (MIT KEMAR).

Install: copy "Thin Walls.vst3" (the whole folder) to
  C:\Program Files\Common Files\VST3\
The standalone (Thin Walls.exe) needs no install: it can load and loop a WAV
file as the source, for auditioning without a DAW.

Manual: Thin-Walls-Manual.pdf.  Site: https://peterboggild.github.io/BrokildApps/
