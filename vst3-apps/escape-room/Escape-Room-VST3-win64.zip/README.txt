ESCAPE ROOM
A noise machine that will not tell you what its knobs do.
Brokild Apps  -  build 260822.1  -  August 2026  -  Windows 64-bit


WHAT IS IN HERE
---------------
  Escape Room.vst3          the plugin (a FOLDER - copy the whole thing)
  Escape Room.exe           the same instrument, standalone
  Escape-Room-Manual.pdf    15 pages: quick start, reference, recipes


INSTALL
-------
  1. Copy the whole "Escape Room.vst3" FOLDER into your system VST3
     directory:  C:\Program Files\Common Files\VST3\
     A sub-folder such as ...\VST3\Brokild\ is fine; hosts look inside.
     Windows will ask for administrator permission. That is normal.

  2. Start your DAW and rescan plugins.
     In Ableton Live: Preferences - Plug-Ins - Rescan.

  3. It appears as an INSTRUMENT called "Escape Room", by Brokild.
     Drop it on a MIDI track. It starts making sound immediately.

  Or just double-click "Escape Room.exe" - no installation needed.


THIRTY SECONDS OF INSTRUCTIONS
------------------------------
  Nothing on the panel is labelled with what it does. That is the point.

  - It makes sound the moment you load it. MIDI notes do not start the
    sound; they tune the resonant filter that everything passes through.

  - BIND (middle panel, bottom left) is the master mystery knob. At zero
    the room is inert and every control does exactly what it says. That
    is the setting to learn on.

  - The SIGIL is six lamps and a number, 0 to 63. It rewires the machine.
    The same sigil always builds the same wiring, so anything you find
    can be found again. The map at the bottom right remembers where you
    have been.

  - The red button at the top right empties every feedback store. Use it
    freely - there are three feedback paths in here.

  - There is a legend hidden in the panel. Tap the keyhole three times.


NOTES
-----
  The interface is drawn in a WebView2 surface, which every current
  Windows 10 and 11 already has. If the window comes up blank, install
  the free Microsoft Edge WebView2 Runtime and reopen the plugin. The
  instrument keeps making sound with the window shut either way.

  This is loud, and there is a brick-wall limiter permanently after the
  output. That is a safety device, not a mix decision - put it on a
  track with a fader like anything else.

  Free. No installer, no account, no telemetry, nothing phones home.
  Use at your own peril. It may generate unique, beautiful, scary or
  useless sounds, and it may crash your DAW project. Play unsafely.

  Peter Boggild / Brokild, August 2026.
