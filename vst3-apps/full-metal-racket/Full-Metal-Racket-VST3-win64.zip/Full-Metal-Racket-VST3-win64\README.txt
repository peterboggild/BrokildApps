FULL METAL RACKET
An analogue drum machine. Twelve voices that behave like one kit in one
room, a thirty-two step sequencer with a last step per lane, and two
hundred kits on a dial.
Brokild Apps  -  build 260827.22  -  August 2026  -  Windows 64-bit


WHAT IS IN HERE
---------------
  Full Metal Racket.vst3         the plugin (a FOLDER - copy the whole thing)
  Full Metal Racket.exe          the same machine, standalone
  Full-Metal-Racket-Manual.pdf   quick start, reference, recipes


INSTALL
-------
  1. Copy the whole "Full Metal Racket.vst3" FOLDER into your system
     VST3 directory:  C:\Program Files\Common Files\VST3\
     A sub-folder such as ...\VST3\Brokild\ is fine; hosts look inside.
     Windows will ask for administrator permission. That is normal.

  2. Start your DAW and rescan plugins.
     In Ableton Live: Preferences - Plug-Ins - Rescan.

  3. It appears as an INSTRUMENT called "Full Metal Racket", by Brokild.

  Or just double-click "Full Metal Racket.exe" - no installation needed.


THE IDEA
--------
  A drum machine is usually twelve independent synthesisers wired to a
  mixer. The parts never quite belong together, and everyone reaches
  for bus compression to fake the missing glue.

  This one is built the other way round. Four controls sit above the
  strips and none of them belongs to a channel:

    RAIL SAG   one power supply, shared. A hard hit pulls it down and
               everything dips for a few milliseconds - level AND
               pitch. The pitch part is why sag glues in a way a
               compressor cannot.
    BLEED      the web. Any trigger EXCITES the other channels'
               resonators without firing their envelopes, so a snare
               rings the toms and a kick buzzes the hats.
    KIT BODY   one resonator every channel feeds. The shell they all
               sit in. Not a reverb - a coupling.
    AGE        per-channel component tolerances, drifting slowly, so
               no two hits are quite identical.

  Every one of them is EXACTLY absent at zero, so you can switch the
  glue off and hear precisely what each was doing.


THE TWELVE
----------
  BD 1  BD 2  SD 1  SD 2  TOM 1  TOM 2  TOM 3  FX  CH  OH  CY 1  CY 2

  In the order every classic machine uses, read from the floor upward:
  kick, snare, toms low to high, percussion, then metal. The FX voice
  sits in the 808's claves-and-cowbell slot, which is where it belongs.

  There is NO ACCENT channel, and you will look for one. Accent here is
  per STEP - a velocity on every step of every lane - which is the same
  idea in its modern form and rather more use.

  The hat is two channels that behave like one. CH and OH ship LINKed:
  OH mirrors CH's tune and model, and CH chokes OH hard. Unlink and
  they are independent, which is occasionally wanted and always
  physically wrong - so link is the default.

  No VCA. On the ping models DECAY *is* the resonator's Q, the way the
  808 did it: the circuit rings and stops ringing.


THIRTY SECONDS OF INSTRUCTIONS
------------------------------
  - The arrows either side of the display step through 200 kits.
    Click the display for the browser; RANDOM dials one at random.
  - Press STEPS and click cells. The play key runs it - on your DAW's
    tempo if the transport is rolling, on its own if not.
  - LAST, at the right of each lane, is where that lane's loop ends.
    Hats at 16 and toms at 12 drift for four bars before they agree.
  - Shift-click a step to select it, then set its velocity, chance,
    ratchet, microtiming and condition on the five knobs below.
  - REBOUND turns one trigger into a bounce: low is a flam, middle a
    drag, high a buzz roll.
  - KEY makes a channel chromatic, and the decay scales with pitch, so
    a low note rings longer - a tuned kick that is actually tuned.
  - A and B are SLOTS, not switches. Press A to hold this kit, change
    the machine, press B, and MORPH blends between them. Shift-click a
    lit slot to empty it.


THE TRANSPORT
-------------
  RUN starts from step one. PAUSE stops where it is and pressing it
  again continues from there - SPACE does the same. Two keys rather
  than one toggle, because "start again" and "carry on" are different
  intentions and a single button has to guess which you meant.

  RECORD writes what you play - pads or MIDI - into the current
  pattern, at the NEAREST step of that lane. Not the step just passed:
  quantising backwards makes everything you played sound late.


OUTPUTS
-------
  Main stereo, plus one mono aux per channel, all disabled until your
  host enables them. The 2X button sets oversampling: about 6 % of a
  core at 1x, 10 % at 2x, 18 % at 4x.


PATCHES
-------
  SAVE writes a .fmrkit file - the whole machine, sequencer and world
  rack included. They go in

      Documents\Brokild patches\Full Metal Racket

  where every Brokild plugin has a folder of its own. Deliberately NOT
  beside the installed .vst3: that is somewhere an installer can reach
  and replace, and work has been lost that way.

  A loaded patch names itself on the display in red, marked USER
  PATCH. Dialling a kit takes it back.


WHAT THE BENCH PROVES
---------------------
  Every build is run through an offline bench that renders real audio
  and measures it - tuning within half a cent, a played octave at
  2.0004, fifteen decibels of velocity range, sequencer placement
  inside one sample of the host clock, and all two hundred kits
  bounded, audible and unlike each other. 1610 checks at the time of
  writing. The numbers in the manual come from it, not from anyone's
  opinion.


NOTES
-----
  The interface is drawn in a WebView2 surface, which every current
  Windows 10 and 11 already has. If the window comes up blank, install
  the free Microsoft Edge WebView2 Runtime and reopen the plugin. The
  audio keeps working with the window shut either way.

  Free. No installer, no account, no telemetry, no network access at
  all.

  Peter Boggild / Brokild, August 2026.
