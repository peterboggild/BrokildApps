PROXIMA CENTAURI b - ARTEFACT B2311.22
Field record B2311. Recovered day 81, dry cistern, Kell Rille.

WHAT IS IN THIS ARCHIVE

  Artefact B2311.22.vst3   the frame, as a Windows VST3
  Artefact B2311.22.exe    the same frame, standing alone
  Proxima Centauri b -
    Field Findings.pdf     what was established about both recovered objects,
                           and the questions the survey could not close

INSTALLING

  Copy the .vst3 folder into
      C:\Program Files\Common Files\VST3\
  and rescan in your host. The standalone needs nothing.

A NOTE ON WHAT THIS IS

  The object has no controls. Everything named on the frame was named by the
  expedition, for its own convenience, and describes what the apparatus does
  rather than any faculty the object possesses.

  The object has no off state. It was sounding when it was found and it has
  sounded since; the frame can open onto that sound or close again, and that
  is the whole of the interaction.

  What you handle is a three-dimensional section through a four-dimensional
  body. Moving the section does not alter the object. A different part of it
  is simply present.

  Nothing here is a picture. Every surface shown is computed as the section
  moves, because no picture would stay correct.

Requires Windows 10 or later, 64-bit, and a VST3 host.
Field record B2311 - both objects remain active.