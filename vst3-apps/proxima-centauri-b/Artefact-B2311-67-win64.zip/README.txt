PROXIMA CENTAURI b - ARTEFACT B2311.67
Field record B2311. Recovered day 204, vault field, Sabik Terminator.

WHAT IS IN THIS ARCHIVE

  Artefact B2311.67.vst3   the frame, as a Windows VST3
  Artefact B2311.67.exe    the same frame, standing alone
  Proxima Centauri b -
    Field Findings.pdf     what was established about both recovered objects,
                           and the questions the survey could not close

INSTALLING

  Copy the .vst3 folder into
      C:\Program Files\Common Files\VST3\
  and rescan in your host. The standalone needs nothing.

A NOTE ON WHAT THIS IS

  This object is not a body but a lattice: a regular four-dimensional array,
  of which we meet only a section. The section is a tiling of eightfold
  symmetry - perfectly ordered, and never repeating anywhere in its extent.

  Its sound belongs to a category between tone and noise which mathematics
  has always described and no material we have made produces: energy occupies
  a set of frequencies that is infinitely subdivided and yet takes up no width
  at all.

  Moving the section does not reveal a different part of a body, as it does
  with B2311.22. It makes the lattice REARRANGE - local reorganisations that
  propagate outward, matter appearing and disappearing at the rim, the whole
  settling into an arrangement equally ordered and equally non-repeating.

  Sixty-seven of these were recovered, each at the centre of its own void,
  spaced with a regularity that survives measurement. No two voids touched.

  The object has no controls and no off state. Everything named on the frame
  was named by the expedition, for its own convenience.

  Nothing here is a picture. Every surface shown is computed as the section
  moves, because no picture would stay correct.

Requires Windows 10 or later, 64-bit, and a VST3 host.
Field record B2311 - both objects remain active.