PROXIMA CENTAURI b - ARTEFACT B2311.67
Field record B2311. Recovered day 204, vault field, Sabik Terminator.

WHAT IS IN THIS ARCHIVE

  Artefact B2311.67.vst3   the frame, as a Windows VST3
  Artefact B2311.67.exe    the same frame, standing alone
  Proxima Centauri b -
    Field Findings.pdf     what was established about both recovered objects,
                           and the questions the survey could not close

INSTALLING

  Copy the .vst3 folder into
      C:\Program Files\Common Files\VST3\
  and rescan in your host. The standalone needs nothing.

A NOTE ON WHAT THIS IS

  This object is not a body but a lattice: a regular four-dimensional array,
  of which we meet only a section. The section is a tiling of eightfold
  symmetry - perfectly ordered, and never repeating anywhere in its extent.

  Its sound belongs to a category between tone and noise which mathematics
  has always described and no material we have made produces: energy occupies
  a set of frequencies that is infinitely subdivided and yet takes up no width
  at all.

  Moving the section does not reveal a different part of a body, as it does
  with B2311.22. It makes the lattice REARRANGE - local reorganisations that
  propagate outward, matter appearing and disappearing at the rim, the whole
  settling into an arrangement equally ordered and equally non-repeating.

  Sixty-seven of these were recovered, each at the centre of its own void,
  spaced with a regularity that survives measurement. No two voids touched.

  The object has no controls and no off state. Everything named on the frame
  was named by the expedition, for its own convenience.

  Nothing here is a picture. Every surface shown is computed as the section
  moves, because no picture would stay correct.

ON WARMING IT

  Held at the temperature of liquid nitrogen the object is quiet in a
  particular sense: its quantities hold still, and it does only what it is
  asked to do. Warmed, they begin to drive ONE ANOTHER. Raise one and three
  or four others start to move - some further, some merely sooner - along
  connections that are fixed, that do not change while the object is
  observed, and that are different in every specimen recovered.

  The survey could not close the question of what the connections are for.
  They are not a fault: they are too regular, and too particular to each
  object. The suspicion recorded in the findings, and marked there as a
  suspicion, is that this is the channel its builders spoke on, and that the
  sixty-seven were spaced as they were so that no two would drive each other.

  The frame carries a reading in kelvin at its foot. What the expedition
  found readable lies between the nitrogen temperature and roughly that of a
  room. Above five hundred kelvin the section itself will not hold still, and
  the object can no longer be said to be where it was put.

THE BENCH

  The four findings were recovered from one site, and on the bench they
  behave as if they still were. The SITE button on the frame opens the
  bench's settings, which every finding present shares: CLIMATE - one
  temperature for all of them - and TIMING - cooled and set close together,
  they fall into step; warm, or far apart, each keeps its own time. This
  lattice joins by rocking its section through the fourth dimension in the
  bench's time, the rim flipping as it goes. Both are off unless you turn
  them on, and off, each finding is exactly what it was.

Requires Windows 10 or later, 64-bit, and a VST3 host.
Field record B2311 - both objects remain active.