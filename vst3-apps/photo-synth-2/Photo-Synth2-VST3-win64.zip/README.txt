﻿Photo-Synth2 - VST3 instrument (Windows, 64-bit)
=================================================
Build 260826.1

Play the colours of four photographs: drag across a photo and the colour under
the cursor becomes a tone, a second photo shapes the filter, a third the
envelope, and a fourth drives the effects.

INSTALL
-------
1. Unzip this archive.
2. Copy the whole "Photo-Synth2.vst3" FOLDER into:

     C:\Program Files\Common Files\VST3\

   (keep it as a folder - do not copy just the file inside it)
3. Rescan plugins in your DAW. It appears as "Photo-Synth2" by Brokild.

Then read Photo-Synth2-Manual.pdf - it has a five-minute quick start, a full
control reference and nine things to try.

REQUIREMENTS
------------
- Windows 10/11, 64-bit
- A VST3 host (Ableton Live, Reaper, Cubase, Bitwig, FL Studio, ...)
- Microsoft Edge WebView2 Runtime, which is preinstalled on current Windows.
  If the plugin window stays blank, install it from:
  https://developer.microsoft.com/microsoft-edge/webview2/

WHAT IS NEW IN BUILD 260826.1
-----------------------------
- AUTOMOTION. Hold SHIFT and drag across any photo to lay down a line the
  cursor then walks on its own; hold CTRL and drag to lay down a circle
  centred on the point you pressed. Drawing a path makes no sound - you are
  describing a shape, not performing one - and the moment you let go the
  path arms, the new Automotion panel opens on the pad you drew, and every
  other panel folds away.
  Each of the four pads keeps its own path and its own settings: speed
  (0.1x to 4x, on top of the Motion slider in the title bar), Loop or One
  shot, Clockwise or Counter for a circle, and Triangle or Sine for a line -
  constant speed all the way, or easing into both ends.
  One shot stops the cursor where the path ends and leaves it there; the
  path stays armed, so the next note or a tap on the pad fires it again.
  Speed and direction are safe to move while a path is running: the replay
  carries an accumulated phase rather than a start time, so nothing jumps.

- SAVE and LOAD in the title bar, reachable in Play mode. Save opens an
  ordinary Save dialog on your preset folder; Load opens the whole library
  as a menu, with sub-folders flying out sideways as sub-menus alongside the
  loose presets. BROWSE... at the foot of that menu reaches anywhere on disk.
  Save somewhere else and that becomes your preset folder from then on -
  unless you were simply filing it in one of its own sub-folders.

- The preset folder now defaults to a folder called "User presets" sitting
  beside the installed .vst3, created on first use, so a library travels
  with the plugin. Where that cannot be written to, Documents\Photo-Synth2
  Presets is used instead as before.

- RANDOM in the title bar throws a new set of numbers at every sound
  control at once - including the effect rack and which parameters the FX
  photo drives - and deliberately leaves the photographs, the cursors and
  the motion paths exactly where they are. Volume, Limit and Motion are left
  alone too. A few controls are randomised over a safe part of their range
  rather than the whole of it, because a few of them are not safe at the top.

WHAT WAS NEW IN BUILD 260826.1
-------------------------------
- Hardened against a crash when the host starts an offline render with the
  plugin window open. Starting a render makes the host tear the audio engine
  down and prepare it again; the reverb convolution was being prepared on
  the host thread while the editor could be loading a new impulse response
  from its own thread, which is not allowed, and the flags saying an impulse
  was loaded survived the re-prepare that had just cleared it - so the
  renderer could run a convolution that no longer had one. The two are now
  serialised and the flags are cleared with the engine.
  This is a fix for a real fault found by reading the code against a crash
  log, not a confirmed reproduction: the dump the host wrote was empty.
  If a render still crashes, keep the crash report - with a dump that has a
  stack in it this becomes a five-minute job.

WHAT WAS NEW IN BUILD 260826.1
-------------------------------
- Fixed: a SPECTRA character no longer swallows edits you make while it is
  armed. A character borrows a few of the instrument's controls and hands
  them back on release - but if you moved one of them yourself, it used to
  be wound back to the value it had when you armed the character, silently.
  That is why a character could sound different the second time you armed
  it. Now whatever you touch is yours: your value stays, the release leaves
  it alone, and the character will not write over it again.
- New reset button on each character, beside the (?). It puts that one
  character back the way it arrives - its own knobs to their factory
  positions, and it takes back any of its controls you have borrowed. What
  the patch looked like before you armed it is still remembered, so
  releasing afterwards still restores that. Nothing else is touched.

WHAT WAS NEW IN BUILD 260826.1
-------------------------------
- A LIGHT slider in the top bar, beside Motion and Zoom. It lifts the whole
  console out of the dark - panels, pads, buttons and the page behind them -
  and leaves the four photographs exactly as they are, so nothing you are
  reading colour from is altered. Off by default; double-click the slider to
  return there. Remembered for this installation, like Zoom, rather than
  saved with a patch.
- The manual documents it, and its top-bar plate is re-shot.

WHAT WAS NEW IN BUILD 260826.1
-------------------------------
- Every effect now carries the same illuminated red rocker as the SPECTRA
  characters, at pedal size, in place of the old power button.
- The four sections of SOUND fold away. Folded, the whole strip is the
  nameplate, so clicking anywhere on it opens the section; open, the
  nameplate closes it again.
- The Motion panel is gone. Its two controls that earned their keep moved:
  Clear sits on each photo beside Rec, Latch and Pause, and Motion speed
  is in the top bar next to Zoom - where it can still be reached in Play
  mode, which is where a moving cursor matters. The two-finger Line/Circle
  switch went with the panel; two fingers still draw a line.
- How it works is gone too; the manual covers the same ground and stays
  current.

WHAT WAS NEW IN BUILD 260826.1
-------------------------------
- Fixed: several SPECTRA characters moved the note itself.
  * The voice you play is now always the note you asked for. The detune
    cluster used to lay the voices out around the ensemble, which left
    voice one at the bottom rung - 72 cents flat under Dark Drone. The
    cluster keeps exactly the same width; it now grows around the note
    instead of dragging it down. Multi-voice patches are about 9 cents
    sharper than before, because they were that much flat.
  * Psychedelic Pink, Glass Cathedral and Insect Choir no longer rewrite
    Spread. Spread decides which pixels of the tone photo the extra voices
    read, and every pixel is a different colour and so a different note -
    moving it re-pitched the whole stack by up to three semitones. The
    swirl, the cathedral and the swarm are otherwise untouched.
  * Tape Seance: with the Sag knob shut there is now no pitch sag at all.
    It used to keep a floor of 15 %, so every note bent on the way out
    with no way to stop it. Full travel is unchanged.
  Dark Drone still drops an octave (its Sub level) and still bends the note
  (Env -> Pitch), and Tape Seance still wows - those are the instruments,
  and all of them have their own sliders.

WHAT WAS NEW IN BUILD 260826.1
-------------------------------
- Key follow in the Filter unit: Off / Half / Full. The cut-off tracks the
  lowest note you are playing - the bass of a chord, not the last key
  pressed - measured from C3, so a patch dialled in at C3 sounds the same
  and everything above it opens up.
- The Q factor reaches much further down: the slider now runs 0.05x to 4x.
  50 % is still exactly 1x, the original sound, and the upper half is
  unchanged; the lower half is stretched, so settings you saved below 50 %
  are gentler than they were.
- Dreamy Hoover no longer plays by itself. The cursor is still placed on
  photo 1, but the latch is off, so the patch waits for you to touch it.
- A Pause button on every photo. It holds a running motion where it stands
  without losing the recording; releasing it picks the loop up where it
  stopped rather than jumping.
- The motion path now shows where it begins: a small white dot at the start
  of the loop, which makes closing a gesture into a clean loop far easier.

WHAT WAS NEW IN BUILD 260826.1
-------------------------------
- Presets are files again. Choose a folder and every .json preset in it
  appears in one menu, with subfolders as submenus. Save writes a file
  there; type "Pads/Warm bells" to file it in a subfolder, which is made
  for you. The folder is remembered for every project, every host and
  every restart, so a preset library can live on a drive you back up.
- Fixed: the response graph ignored the Q factor. Q was reaching the
  sound all along, but the curve was drawn from the raw colour resonance
  and was never redrawn when the slider moved. It follows Q now.
- The Skin selector is gone; the Boutique look, one enclosure per pedal,
  is simply how it looks.
- The per-character Chain switch is gone with it. You order the effects
  yourself; the rack starts as Tube - Stutter - LoFi - Phase - Chorus -
  Delay - Reverb.
- The Spectra panel explanation folds away behind a (?), like each
  module's own.
- Pad size has moved in with the voice, and the Photos & layout unit is
  gone along with its Swap 1-2 button.

WHAT WAS NEW IN BUILD 260826.1
-------------------------------
- Glass Cathedral is restrained: it was burying the oscillator under a slow
  attack, a nearly shut filter and half a wall of reverb. Notes now arrive,
  and saturation, chorus and phaser are left as you set them.
- Envelope routing appears in BOTH places and is linked: arrow-Amp and
  arrow-Filter sit under photo 3 (reachable in Play mode) and again in the
  Sound envelope unit. Move either copy and the other follows. Attack,
  Release and Legato stay in the Sound envelope unit.
- Envelope: a "Shaped by" switch. Photo 3 takes the envelope over when you
  touch it; this hands control back to the Attack and Release sliders, which
  now grey out while the photo is in charge so you can see why they are idle.
- Opens on the "Dreamy Hoover" factory patch; "Naked Oscillator" is the bare
  engine. Set as default makes any patch of yours the one it greets you with.
- The manual is rewritten for this build (31 pages, new screenshots).
- Spread reaches 60 px and the tone photo now shows the patch it reads:
  a soft brightened halo with a dot on every sampling point.
- Industrial Black and Tape Seance no longer self-oscillate, and are level
  matched to the rest.
- Explanations fold away behind a (?) on each module.
- Presets: "Set as default" makes the current patch the startup patch.
- SPECTRA characters can now be combined: arm any number at once; releasing
  one puts back exactly what it changed. Tape Seance no longer runs away
  into self-oscillation.
- New Q factor slider in the Filter unit: scales the resonance the photo
  asks for, in every mode incl. notch, band-pass and the comb. 50 % is the
  original sound; the Low mode remains the classic Moog-style ladder.
- The panel is now called SPECTRA; each module carries the Spectrum name
  in brighter lettering.
- Fixed: a remembered interface zoom could overflow the window sideways and
  make the panel look broken; zoom is now clamped to what the window holds.
- Glass Cathedral now colours your tone instead of replacing the oscillator.
- Smoother tape wow and chorus (cubic delay-line interpolation) and a
  smoother phaser sweep.
- Five new SPECTRUM characters beside Dark Drone: Psychedelic Pink,
  Industrial Black, Glass Cathedral, Tape Seance and Insect Choir. One at a
  time, armed with an illuminated rocker switch; each restores your settings
  exactly when it lets go.
- Tempo sync for the delay and the stutter: lock either to the host tempo
  and pick a note division.
- Tune (±12 semitones) and Fine (±100 cents), plus a Match-to tuner that
  shifts the sounding note to a chosen note by the shortest path.
- Live MIDI keyboard support in the browser version; the plugin already
  takes MIDI from the host.
- New Spectrum panel below Effects for character modules. Dark Drone has
  moved there out of Sound.
- Fixed: a slow DC offset that made the output wander off zero with a
  nine-second period.
- Fixed: closing and reopening the plugin window no longer loses the
  cursor, the armed motions or the latches, and the patch is on screen as
  the window opens instead of after a few seconds of demo photos.
- Fixed: switching Play/Edit no longer moves the cursors, which used to
  change the sound.

WHAT IS IN THE BOX
------------------
Photo-Synth2.vst3            the plugin (a folder - copy all of it)
Photo-Synth2-Manual.pdf      33-page manual: quick start, reference, try this
README.txt                   this file

This VST comes from the curved mind of Professor Brokild, and was programmed
with VScode, ChatGPT and Claude. Use of this is on your own peril. It may
generate unique, beautiful, scary or useless sounds for you, and it may crash
your DAW project. Have fun, play unsafely, unwisely, and unboringly.

Cheers, Peter Boggild, August 2026.
