﻿Photo-Synth2 - VST3 instrument (Windows, 64-bit)
=================================================
Build 260821.4

Play the colours of four photographs: drag across a photo and the colour under
the cursor becomes a tone, a second photo shapes the filter, a third the
envelope, and a fourth drives the effects.

INSTALL
-------
1. Unzip this archive.
2. Copy the whole "Photo-Synth2.vst3" FOLDER into:

     C:\Program Files\Common Files\VST3\

   (keep it as a folder - do not copy just the file inside it)
3. Rescan plugins in your DAW. It appears as "Photo-Synth2" by Brokild.

Then read Photo-Synth2-Manual.pdf - it has a five-minute quick start, a full
control reference and nine things to try.

REQUIREMENTS
------------
- Windows 10/11, 64-bit
- A VST3 host (Ableton Live, Reaper, Cubase, Bitwig, FL Studio, ...)
- Microsoft Edge WebView2 Runtime, which is preinstalled on current Windows.
  If the plugin window stays blank, install it from:
  https://developer.microsoft.com/microsoft-edge/webview2/

WHAT IS NEW IN BUILD 260821.4
-----------------------------
- Five new SPECTRUM characters beside Dark Drone: Psychedelic Pink,
  Industrial Black, Glass Cathedral, Tape Seance and Insect Choir. One at a
  time, armed with an illuminated rocker switch; each restores your settings
  exactly when it lets go.
- Tempo sync for the delay and the stutter: lock either to the host tempo
  and pick a note division.
- Tune (�12 semitones) and Fine (�100 cents), plus a Match-to tuner that
  shifts the sounding note to a chosen note by the shortest path.
- Live MIDI keyboard support in the browser version; the plugin already
  takes MIDI from the host.
- New Spectrum panel below Effects for character modules. Dark Drone has
  moved there out of Sound.
- Fixed: a slow DC offset that made the output wander off zero with a
  nine-second period.
- Fixed: closing and reopening the plugin window no longer loses the
  cursor, the armed motions or the latches, and the patch is on screen as
  the window opens instead of after a few seconds of demo photos.
- Fixed: switching Play/Edit no longer moves the cursors, which used to
  change the sound.

WHAT IS IN THE BOX
------------------
Photo-Synth2.vst3            the plugin (a folder - copy all of it)
Photo-Synth2-Manual.pdf      24-page manual: quick start, reference, try this
README.txt                   this file

This VST comes from the curved mind of Professor Brokild, and was programmed
with VScode, ChatGPT and Claude. Use of this is on your own peril. It may
generate unique, beautiful, scary or useless sounds for you, and it may crash
your DAW project. Have fun, play unsafely, unwisely, and unboringly.

Cheers, Peter Boggild, August 2026.
