﻿Photo-Synth2 - VST3 instrument (Windows, 64-bit)
=================================================

Play the colours of four photographs: drag across a photo and the colour under
the cursor becomes a tone, a second photo shapes the filter, a third the
envelope, and a fourth drives the effects.

INSTALL
-------
1. Unzip this archive.
2. Copy the whole "Photo-Synth2.vst3" FOLDER into:

     C:\Program Files\Common Files\VST3\

   (keep it as a folder - do not copy just the file inside it)
3. Rescan plugins in your DAW. It appears as "Photo-Synth2" by Brokild.

Then read "Photo Synth 2 Manual.pdf" - quick start, full control reference,
and things to try.

REQUIREMENTS
------------
- Windows 10/11, 64-bit
- A VST3 host (Ableton Live, Reaper, Cubase, Bitwig, FL Studio, ...)
- Microsoft Edge WebView2 Runtime, preinstalled on current Windows.
  If the plugin window stays blank, install it from:
  https://developer.microsoft.com/microsoft-edge/webview2/

Note: a DAW maps a plugin once per session, so after updating the plugin you
must restart the DAW - removing and re-adding the device is not enough.

WHAT IS IN THE BOX
------------------
Photo-Synth2.vst3            the plugin (a folder - copy all of it)
Photo Synth 2 Manual.pdf     the manual
README.txt                   this file

This VST comes from the curved mind of Professor Brokild, and was programmed
with VScode, ChatGPT and Claude. Use of this is on your own peril. It may
generate unique, beautiful, scary or useless sounds for you, and it may crash
your DAW project. Have fun, play unsafely, unwisely, and unboringly.

Cheers, Peter Boggild, August 2026.
