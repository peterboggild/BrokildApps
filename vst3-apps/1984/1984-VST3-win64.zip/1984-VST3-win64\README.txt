1984  -  a Brokild polysynth  -  build 260922.1

Eight voices, each of two complete ranks (the CS-80 layout): oscillator,
resonant high-pass, resonant low-pass (12 dB state-variable or a 24 dB ladder),
the initial-level / attack-level filter envelope, an amplifier envelope, level
and pan. Ring modulator, sub-oscillator, touch. Hard sync and poly-mod between
the ranks. Then drive, a three-phase ensemble, a formant choir, a tape with
wow, flutter, saturation, age, dropouts and a VHS mode, and a hall. Forty
factory patches. Brokild World FX rack with five macros.

Install: copy "1984.vst3" (the whole folder) to
  C:\Program Files\Common Files\VST3\
The standalone (1984.exe) needs no install: plug in a MIDI keyboard or play the
on-screen one.

Manual: 1984-Manual.pdf.  Site: https://peterboggild.github.io/BrokildApps/
