BLADE RUINER
An atmospheric synthesiser in three layers. A city that never stops, a
polysynth to play over it, and a machine in the next room counting.
Brokild Apps  -  build 260826.1  -  August 2026  -  Windows 64-bit


WHAT IS IN HERE
---------------
  Blade Ruiner.vst3           the plugin (a FOLDER - copy the whole thing)
  Blade Ruiner.exe            the same instrument, standalone
  Blade-Ruiner-Manual.pdf     quick start, all three layers, recipes


INSTALL
-------
  1. Copy the whole "Blade Ruiner.vst3" FOLDER into your system VST3
     directory:  C:\Program Files\Common Files\VST3\
     A sub-folder such as ...\VST3\Brokild\ is fine; hosts look inside.
  2. Rescan plugins in your DAW. It appears as an INSTRUMENT called
     Blade Ruiner, by Brokild.
  3. Or just run Blade Ruiner.exe, which picks its own audio and MIDI
     devices from its options menu.


THE THREE LAYERS
----------------
  LOS ANGELES is a drone: nine oscillators on one chord, a rain of
  filtered noise, grains of dust, and a reverb big enough to lose a city
  in. It does not need a keyboard. Load the plugin and it is already
  sounding.

  DECKARD is an eight-voice polysynth built the way the big Japanese
  polysynth of 1977 was built - two oscillators and a sub per voice, a
  four-pole ladder with its own envelope, a vibrato that arrives late,
  and an ensemble chorus doing most of the emotional work.

  REPLICANT is a machine: a sixteen-step sequence on the host's clock,
  built from a six-bit seed, driving a two-operator FM voice with an
  inharmonic ratio, a bit-crusher, and a heartbeat on the downbeat.

  Any combination of the three can run at once - but not none of them.
  The last live layer refuses to be switched off, because an atmosphere
  that can be silenced by one click is a mixer channel.


THIRTY SECONDS OF INSTRUCTIONS
------------------------------
  - Click a layer name to open its page; click its lamp to switch the
    layer on or off.
  - On LOS ANGELES, SMOG and DRIFT do more for the atmosphere than
    anything else on the page.
  - On DECKARD, ENSEMBLE above about 70 % stops being a chorus and
    becomes the sound.
  - On REPLICANT, drag SEED and the machine rebuilds at every step. All
    64 seeds are different, and the same seed is always the same
    machine.
  - There is a two-octave keyboard along the bottom for when there is no
    MIDI keyboard in the room.
  - The MOOD dial in the header is the patch: one number from 0 to 999,
    each with its own sound and its own line of text. RANDOM dials one
    at random and leaves the levels alone.


THE MOOD ORGAN
--------------
  There is a dial in the header marked MOOD, and it goes from 0 to 999.
  Every one of those thousand numbers IS a patch: dialling one writes
  every character parameter in all three layers and prints the line of
  text that belongs to that number. RANDOM simply dials at random. The
  levels, the tuning and the limiter are never touched.

  The same number is always the same instrument. Nothing about a mood
  depends on the clock, the session or the machine - 481 today is 481
  next year and 481 on somebody else's computer, which is the only
  thing that makes a three-digit number worth writing down.

  Drag the number, roll the wheel over it, or use the two buttons.
  Shift moves ten at a time. The dial reads - until you turn it: the
  patch the plugin ships with is hand-made and is not one of the
  thousand, and printing a number over a patch that number did not
  produce is a small lie. Loading a patch brings its mood back with it.

  Every mood makes a sound on its own. Not just "one layer live" -
  DECKARD needs keys, and so does a keyed LOS ANGELES or a keyed
  REPLICANT - so if nothing would be free-running, the city comes on
  and stays on.

  Nineteen of the thousand descriptions are written by hand, and five
  of those are Philip K. Dick's own, from "Do Androids Dream of
  Electric Sheep?" - 3, 382, 481, 594 and 888. The dial marks the
  written ones as you pass them. The other 981 are generated from the
  seed by a small grammar, and no two of the thousand share a line.

  451 and 42 are not Dick at all. They belong to other books by other
  authors, and it would be a poor sort of dystopia that did not nod to
  its neighbours. Neither of them winks - they are written as moods, and
  if you do not already know the two numbers you will read past them.

  KIPPLE, on the LOS ANGELES page, is Dick's word too: the useless
  matter that accumulates in an empty building whether or not anybody
  adds to it. It seemed the right name for a control that only ever
  makes things dirtier.

PATCHES
-------
  A patch is a small JSON file holding all 47 values and nothing else.
  They go in a folder called "User presets" beside the installed .vst3,
  so a library travels with the plugin. Where that cannot be written to,
  Documents\Blade Ruiner Presets is used instead. Saving somewhere else
  once makes that the new folder, and the choice is remembered in your
  own settings rather than in the project.


NOTES
-----
  The interface is drawn in a WebView2 surface, which every current
  Windows 10 and 11 already has. If the window comes up blank, install
  the free Microsoft Edge WebView2 Runtime and reopen the plugin. The
  audio keeps working with the window shut either way.

  If Windows refuses to load the plugin at all and mentions an
  "Application Control policy", that is Smart App Control. It decides per
  FILE, from a cloud reputation lookup, and it can block one unsigned
  binary while loading another quite happily: build 260826.1 of this
  plugin was blocked on the machine it was written on while three other
  unsigned plugins in the same folder loaded, and rebuilding the
  identical program cleared it. The block attaches to that exact copy of
  the file rather than to the plugin, so a later build may load where an
  earlier one did not. Failing that, Windows Security > App & browser
  control > Smart App Control lets you turn it off - note that switching
  it off is not reversible without reinstalling Windows. Most machines
  do not have it enabled at all.

  The output has a soft ceiling that is always in place, whatever the
  LIMITER switch is doing. The switch turns off the smooth, musical gain
  reduction; the ceiling stays, because an instrument has no business
  emitting anything above full scale.

  Free. No installer, no account, no telemetry, no network access at
  all. Use at your own peril: it is an atmosphere, and it means it.

  Peter Boggild / Brokild, August 2026.
