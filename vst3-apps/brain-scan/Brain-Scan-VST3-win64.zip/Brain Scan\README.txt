BRAIN SCAN  -  a Brokild synth  -  build 260904.1

A synth that stores no waveforms. A specimen is a VOLUME - a scalar field
filling a cube, exactly like the numbers a scanner records - and a scan line
is a curve through it. One cycle of the sound is the field read along that
curve. The filter's cutoff and the modulator are the same thing read slower:
two more lines. And SCAN blends the GEOMETRY of two anchor lines before the
field is read, so halfway between two sounds is tissue neither of them has
visited. A wavetable crossfades two answers; this moves the question.

Nine specimens: seven fields built to give ordinary, useful waveforms, a
hollow shell, and a simulated brain with skull, cortical folds, a fissure and
ventricles. Lines are drawn on a tomography slice - drag a point and it keeps
its depth, click the tissue to add one - and watched in a ray-marched gantry
where they glow inside the specimen until the tissue closes over them.

WHAT IS IN THIS ARCHIVE

  Brain Scan.vst3          the plug-in, as a Windows VST3 bundle folder
  Brain Scan.exe           the same instrument, standing alone
  Brain Scan Manual.pdf    the manual

INSTALLING

  Copy the folder  Brain Scan.vst3  into
      C:\Program Files\Common Files\VST3\
  and rescan in your host. The standalone needs nothing.

  The panel is a web view and needs the Microsoft Edge WebView2 runtime,
  which is present on every up-to-date Windows 10 and 11.

PATCHES

  Your own patches live in  Documents\Brokild patches\Brain Scan\  as JSON
  files carrying every control, both anchors of all three scanners, the
  specimen and the world rack.

  Brokild  -  https://peterboggild.github.io/BrokildApps/
