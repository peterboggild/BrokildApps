BATTLESTAR OVERDRIVE  -  a Brokild effect  -  build 260919.2

An overdrive named after the band, made with Max Christensen's blessing and
built to live in his universe rather than beside it.

Eight drive engines on one knob, ordered from polite to unhinged: IDLE BURN,
ION DRIVE, PLASMA COIL, AFTERBURNER, RAZOR WING, WARP FOLD, HYPERDRIVE and
SUPERNOVA. The tube tells you which one you are on, runs a starfield that
speeds up as you climb the knob, goes to warp on the seventh and blows up a
star on the eighth. ANTITHRUST widens the image without ever moving the mono
sum. SPACE is one knob across a tape delay, a hall, a shimmer and a harmonic
tremolo. And the fuel gauge means it: play long enough with Autorefill dark
and the engine flames out.

Great at ruining things. That is the point.

GO AND LISTEN TO THE BAND

  Battlestar Overdrive is Max Christensen, out of Copenhagen - garage rock
  swagger welded to soul, disco and indie electronica, played by one person
  with a guitar and no interest in tidying it up. Eclectic, wildly
  entertaining, and the reason this plug-in exists.

WHAT IS IN THIS ARCHIVE

  Battlestar Overdrive.vst3           the plug-in, as a Windows VST3 bundle
  Battlestar Overdrive.exe            the same effect, standing alone
  Battlestar-Overdrive-Manual.pdf     the handbook, 12 pages

INSTALLING

  Copy the folder  Battlestar Overdrive.vst3  into
      C:\Program Files\Common Files\VST3\
  and rescan in your host. The standalone needs nothing installing.

TWO CONTROLS WITH NO KNOB

  The panel has no room for them, so they live in your host's automation list
  only:  SPACE WET  (overall level of the SPACE section; the centre is exactly
  what the SPACE knob does on its own) and  SPACE SYNC  (locks the delay to
  the host clock; FREE by default).

  Brokild  -  https://peterboggild.github.io/BrokildApps/
