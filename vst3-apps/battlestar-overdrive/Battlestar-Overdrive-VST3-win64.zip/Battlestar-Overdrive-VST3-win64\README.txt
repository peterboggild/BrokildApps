BATTLESTAR OVERDRIVE  -  a Brokild effect  -  build 260919.2

I suggested to make a VST3 for Max, and he asked for a Battlestar Overdrive,
named after his solo band. That was too good not to do. So here it is, built
with his blessing.

Eight drive engines on one knob, ordered from polite to unhinged: IDLE BURN,
ION DRIVE, PLASMA COIL, AFTERBURNER, RAZOR WING, WARP FOLD, HYPERDRIVE and
SUPERNOVA. The tube tells you which one you are on, runs a starfield that
speeds up as you climb the knob, goes to warp on the seventh and blows up a
star on the eighth. ANTITHRUST widens the image without ever moving the mono
sum. SPACE flies through no less than five overlapping effects, because too
much is never enough.

Very good at ruining things, beautifully and thoroughly.

And watch the fuel. You don't want to run out. Thrust me.

GO AND LISTEN TO THE BAND

  Battlestar Overdrive is Max Christensen, out of Copenhagen - garage rock
  swagger welded to soul, disco and slacker electronica, performed alone on a
  mashed-up rig of synths, sequencers and samplers with a screen of zany
  visuals behind him. Eclectic, wildly entertaining, and the reason this
  plug-in exists.

WHAT IS IN THIS ARCHIVE

  Battlestar Overdrive.vst3           the plug-in, as a Windows VST3 bundle
  Battlestar Overdrive.exe            the same effect, standing alone
  Battlestar-Overdrive-Manual.pdf     the handbook, 12 pages

INSTALLING

  Copy the folder  Battlestar Overdrive.vst3  into
      C:\Program Files\Common Files\VST3\
  and rescan in your host. The standalone needs nothing installing.

TWO CONTROLS WITH NO KNOB

  The panel has no room for them, so they live in your host's automation list
  only:  SPACE WET  (overall level of the SPACE section; the centre is exactly
  what the SPACE knob does on its own) and  SPACE SYNC  (locks the delay to
  the host clock; FREE by default).

  Brokild  -  https://peterboggild.github.io/BrokildApps/
