HIGH TIDE  -  a Brokild synth  -  build 260904.2

A wavetable synth that stores no waveforms. A frame is a bowl on a sculpted
terrain; the waveform is what a mass does when it is dropped into that bowl,
integrated by Newton's law at audio rate. Position is where the ball IS.
Morphing is travel across the terrain. The TIDE floods the passes between the
valleys; PINS on a timeline tow the ball to where you want it, when you want
it there. ROCK drives the whole terrain at the note and opens period doubling
and chaos. Twelve factory terrains, a 16-bit PNG in and out, a photograph as a
terrain, the Brokild World FX rack with five macros.

WHAT IS IN THIS ARCHIVE

  High Tide.vst3          the plug-in, as a Windows VST3 bundle folder
  High Tide.exe           the same instrument, standing alone
  High Tide Manual.pdf    the manual

INSTALLING

  Copy the folder  High Tide.vst3  into
      C:\Program Files\Common Files\VST3\
  and rescan in your host. The standalone needs nothing.

PATCHES

  Your own patches live in  Documents\Brokild patches\High Tide\  as JSON
  files that carry the terrain (a 16-bit PNG inside), the pins and the rack.

  Brokild  -  https://peterboggild.github.io/BrokildApps/
