HAIRFRYER
A vocal strip that turns a clean singing voice into a metal one --
growls, gutturals, squeals, fry -- by wrecking the part of the voice
a fuzz pedal can never reach.
Brokild Kitchen Appliances  -  build 260826.3  -  August 2026  -  Windows 64-bit


WHAT IS IN HERE
---------------
  Hairfryer.vst3            the plugin (a FOLDER - copy the whole thing)
  Hairfryer.exe             the same strip, standalone
  Hairfryer-Manual.pdf      the owner's manual & cookbook, 9 pages


INSTALL
-------
  1. Copy the whole "Hairfryer.vst3" FOLDER into your system VST3
     directory:  C:\Program Files\Common Files\VST3\
     A sub-folder such as ...\VST3\Brokild\ is fine; hosts look inside.
     Windows will ask for administrator permission. That is normal.

  2. Start your DAW and rescan plugins.
     In Ableton Live: Preferences - Plug-Ins - Rescan.

  3. It appears as an EFFECT called "Hairfryer", by Brokild.
     Put it on a vocal channel.

  Or just double-click "Hairfryer.exe" - no installation needed.


THE IDEA, IN ONE PARAGRAPH
--------------------------
  A sung note is a SOURCE (the glottal pulses) played through a FILTER
  (your throat and mouth - the formants, the vowels). A distortion
  pedal mangles the filter, so the words die and it sounds like a
  pedal. A real screamer keeps the filter and wrecks the SOURCE: the
  false folds go into period-doubled or chaotic vibration over the
  sung pitch. The Hairfryer does the same thing to a signal: it splits
  your voice into source and filter in real time (LPC), drives the
  source with a genuine chaotic map stepped once per glottal period --
  plus a self-oscillating "false folds" resonator that locks onto a
  fraction of your pitch, and noise fired in step with your pulses --
  then puts YOUR vocal tract back on top. The melody survives. The
  words survive. The voice is a monster.

  Measured, not hoped: the input's vowel contrast is 35.2 dB, the
  growled output keeps 35.0 dB of it, and the same voice through a
  fuzz pedal collapses to 19.7 dB.


THIRTY SECONDS OF INSTRUCTIONS
------------------------------
  Pick a PROGRAMME:

    CLEAN PASS    the strip alone, fryer off
    WARM STRIP    tube, glue, sheen - still a singing voice
    AIR FRY       a worn edge over the clean voice
    FALSE CORD    the classic low growl (period-2, folds at f/2)
    GUTTURAL      deeper - the period-three window
    PIG SQUEAL    throat shrunk, folds pushed high
    BLACKENED     chaotic, bright, torn
    DOOM LOW      slow and huge (f/4, big chest)
    TWO THROATS   growl under, shriek over

  Then SING LOUD, CLEAN AND SUPPORTED. The fryer scales everything by
  your own voice: commitment in, monster out; whisper in, nothing to
  wreck. Ride BLEND against the clean voice - it is gain-matched, so
  the growl cannot win by being louder.

  CHAOS walks the actual bifurcation cascade of vocal-fold physics
  (the LCD shows the map parameter r). GRIP is how deep the pattern
  carves - if you cannot find the growl, raise GRIP first. THROAT
  resizes you without moving the pitch. SPLIT is the second voice.

  Around the basket: gate, de-esser, 4-band EQ, an analogue-style
  compressor, tube heat with sparkle, and a lookahead limiter.
  About 4.6 ms latency at 48 kHz, constant, reported to the host.


FIRST RUN ON WINDOWS
--------------------
  The binaries are not code-signed. Windows SmartScreen or Smart App
  Control may warn on first launch of the standalone; the VST3 inside
  a DAW is normally untroubled. Every build is checked against a
  measurement bench before release (see the manual's appendix for
  what is proved).


  Brokild - free, as in: it is yours now.
