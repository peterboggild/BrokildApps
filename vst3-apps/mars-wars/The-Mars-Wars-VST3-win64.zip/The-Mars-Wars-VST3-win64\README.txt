THE MARS WARS
Multiband distortion. Five bands, sixteen algorithms, a patch bay under
the front panel, and a gain match that keeps you honest.
Brokild Apps  -  build 260826.1  -  August 2026  -  Windows 64-bit


WHAT IS IN HERE
---------------
  The Mars Wars.vst3          the plugin (a FOLDER - copy the whole thing)
  The Mars Wars.exe           the same effect, standalone
  The-Mars-Wars-Manual.pdf    quick start, all sixteen algorithms, recipes


INSTALL
-------
  1. Copy the whole "The Mars Wars.vst3" FOLDER into your system VST3
     directory:  C:\Program Files\Common Files\VST3\
     A sub-folder such as ...\VST3\Brokild\ is fine; hosts look inside.
     Windows will ask for administrator permission. That is normal.

  2. Start your DAW and rescan plugins.
     In Ableton Live: Preferences - Plug-Ins - Rescan.

  3. It appears as an EFFECT called "The Mars Wars", by Brokild.
     Drop it on a channel, a bus, or the whole mix.

  Or just double-click "The Mars Wars.exe" - no installation needed.


THE IDEA
--------
  Distortion normally sells itself by getting louder: turn the knob, it
  gets fatter, and the ear says yes before the brain has had a chance.

  Here every band measures its own loudness immediately before and
  immediately after its shaper, and corrects the difference. Turning
  DRIVE up changes what it sounds like without changing how loud it is,
  so an A/B is an honest one. Measured across the full drive range the
  level moves by 0.44 dB at the very worst, and under 0.15 dB for most
  of the sixteen algorithms.

  Switch AUTO GAIN off and DRIVE becomes a volume knob again, which is
  occasionally exactly what a part needs.


THE SIXTEEN ALGORITHMS
----------------------
  Mild          WARM, VALVE, OVERDRIVE, TAPE
  Harsh         FUZZ, RAZOR, FOLD, SINE FOLD
  Digital       RECTIFY, BITCRUSH, DECIMATE, SLEW
  Unreasonable  RING MOD, CHEBYSHEV, SHRED, ANNIHILATE

  Each band picks its own. CHARACTER is a different control on every one
  and is labelled with whatever it currently is. BIAS works on all
  sixteen: it shifts the shaper's operating point, which is what makes
  even harmonics.


THIRTY SECONDS OF INSTRUCTIONS
------------------------------
  - Drag the markers on the spectrum to move the crossovers.
  - Press 1 to 5 for the band count. That also re-spaces the crossovers.
  - SOLO a band to hear what you are actually doing to it.
  - RANDOM re-rolls every algorithm, drive and character, and leaves
    your input, output, dry/wet and band levels exactly where they are.
  - PATCH BAY lifts the front panel off; underneath, eight cables let
    any band drive any other band's knobs.
  - There is a limiter on every band (CEILING) and a brick wall on the
    output. The CLAMP lamp lights when the output limiter is working.


THE PATCH BAY
-------------
  Press PATCH BAY in the header and the front panel lifts off. Under it
  is a column per band and eight cables.

  Out of every band comes its AUDIO OUT and its ENV - what it sounds
  like, and how loud it is right now. The side rails carry INPUT ENV and
  OUTPUT ENV, the same reading for the whole machine.

  None of those has a knob on the front panel, and none is meant to.
  They are taps - places to listen to what the machine is already doing
  - not controls. An envelope is just how loud something is at this
  instant, as a number: patch one into a knob and the knob follows that
  loudness. Into every band
  go AUDIO IN, DRIVE, LEVEL, CHARACTER and CEILING, and along the floor
  are the four crossover frequencies.

  Drag from a hole to a hole to patch. Wheel over a cable for the
  amount, -100 % to +100 %; a negative cable turns its destination down
  as the source gets louder, and is drawn hollow. Double-click a cable,
  or a patch point, to pull it out.

  Every patch point is a block of THREE holes, so three cables can
  leave or arrive at the same point - one plug per hole, and a fourth
  is refused because there is nowhere to put it.

  Try band 1 ENV into band 4 DRIVE at about -60 %, and the top of
  the spectrum backs off every time the bass hits. Try band 3 AUDIO OUT
  into band 5 AUDIO IN and the top band starts distorting the middle
  band instead of the source, which is where it stops sounding like a
  multiband and starts sounding like one machine.

  Audio cables make loops. Every one is delayed a single sample, every
  band ends in its own limiter, and the auto gain is measuring rather
  than modelling - so it hears a loop building and takes it back down.
  Bench-tested with all five bands wired in a ring at full drive: peak
  1.000, and still 1.000 after the input was cut.

  The cables are parameters like everything else, so a host can
  automate a patching and a preset carries the wiring with it.


THE PANEL LIGHT
---------------
  LIGHT, at the left of the header, is for rooms this panel was not
  designed for. It is a gamma curve rather than a brightness control:
  it lifts the shadows, where everything on a panel this dark actually
  lives, and leaves the highlights where they are instead of flattening
  them into white. Double-click the slider to put it back to nothing.
  It is remembered per machine and never saved into a preset.

NOTES
-----
  The interface is drawn in a WebView2 surface, which every current
  Windows 10 and 11 already has. If the window comes up blank, install
  the free Microsoft Edge WebView2 Runtime and reopen the plugin. The
  audio keeps working with the window shut either way.

  Presets go in a folder called "User presets" beside the installed
  .vst3, so a library travels with the plugin. Where that cannot be
  written to, Documents\Mars Wars Presets is used instead.

  Free. No installer, no account, no telemetry, no network access at
  all. Use at your own peril: it is a distortion, and it means it.

  Peter Boggild / Brokild, August 2026.
